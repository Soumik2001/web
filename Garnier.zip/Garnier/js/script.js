function responsiveSlider() {
  const slider = document.querySelector('.swiperSection');
  const sliderList = slider.querySelector('ul');
  const prev = document.getElementById('prev');
  const next = document.getElementById('next');

  if (!slider || !sliderList || !prev || !next) {
    console.error('Elements not found. Make sure #prev, #next, and .swiperSection ul exist.');
    return;
  }

  const itemsToShow = 5; // Number of items to display at once
  const totalItems = sliderList.querySelectorAll('li').length;
  const effectiveWidth = 920; // Width available for images within .swiperSection
  const itemWidth = effectiveWidth / itemsToShow; // Each image's width
  let currentPosition = 0;

  // Set width of each item and total width of the slider list
  slider.style.width = '960px'; // Total including Lside and Rside
  sliderList.style.width = `${itemWidth * totalItems}px`;
  sliderList.querySelectorAll('li').forEach((item) => {
    item.style.width = `${itemWidth}px`;
  });

  // Move to the next set of items
  function nextSlide() {
    if (currentPosition > -(itemWidth * (totalItems - itemsToShow))) {
      currentPosition -= itemWidth * itemsToShow;
    } else {
      currentPosition = 0; // Loop back to start
    }
    updateSliderPosition();
  }

  // Move to the previous set of items
  function prevSlide() {
    if (currentPosition < 0) {
      currentPosition += itemWidth * itemsToShow;
    } else {
      currentPosition = -(itemWidth * (totalItems - itemsToShow)); // Loop back to last set
    }
    updateSliderPosition();
  }

  // Update the slider position
  function updateSliderPosition() {
    sliderList.style.transform = `translateX(${currentPosition}px)`;
  }

  // Event listeners for navigation buttons
  prev.addEventListener('click', prevSlide);
  next.addEventListener('click', nextSlide);
}

window.onload = responsiveSlider;





