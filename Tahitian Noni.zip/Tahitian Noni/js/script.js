document.addEventListener("DOMContentLoaded",function(){
const coll = document.getElementsByClassName("collapsible");
const mainImage = document.getElementById("mainImage");

for(let i=0;i<coll.length;i++){

coll[i].addEventListener("click",function(){

for(let j=0; j<coll.length;j++){
if(coll[j] !==this){
coll[j].classList.remove("active");
let content = coll[j].nextElementSibling;
if(content) content.style.maxHeight = null;
}

}


this.classList.toggle("active");
let content = this.nextElementSibling;
if(content){
if(content.style.maxHeight){
content.style.maxHeight = null;
}else{
content.style.maxHeight = content.scrollHeight+8.5 + "px";
}
}

const newImageSrc = this.getAttribute("data-image");

if(newImageSrc && newImageSrc.src !== newImageSrc){
mainImage.classList.add("fade-out");

setTimeout(()=>{
mainImage.src= newImageSrc;
mainImage.classList.remove("fade-out");
mainImage.classList.add("fade-in");

setTimeout(()=>{
mainImage.classList.remove("fade-in");
},300);
},300);

}

});

}


if(coll.length>0){
const firstColl = coll[0];
const firstContent = firstColl.nextElementSibling;
firstColl.classList.add("active");

if(firstContent){
firstContent.style.maxHeight = firstContent.scrollHeight+8.5+ "px";
}
mainImage.src = firstColl.getAttribute("data-image");
}



});