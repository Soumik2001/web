document.querySelectorAll('.footerUL li').forEach(item=>{
item.addEventListener('click',()=>{
const link = item.querySelector('a');

if(link){
window.location.href=link.href;
window.open = link.href;
}
})
});




document.addEventListener("DOMContentLoaded", () => {
  const slidesContainer = document.querySelector(".slides");
  const totalSlides = document.querySelectorAll(".slide").length;
  let slideIndex = 0;
  let slideInterval;


  function changeSlide() {
    slideIndex = (slideIndex + 1) % totalSlides;
    slidesContainer.style.transform = `translateX(-${slideIndex * 100}%)`;
    updateRadioButtons();
  }

 
  function updateRadioButtons() {
    const radioButtons = document.querySelectorAll(".control");
    radioButtons.forEach((radioButton, index) => {
      radioButton.checked = index === slideIndex;
    });
  }


  function startAutoplay() {
    clearInterval(slideInterval); 
    slideInterval = setInterval(changeSlide, 5000);
  }

  function stopAutoplay() {
    clearInterval(slideInterval);
  }


  const carousel = document.querySelector(".carosel");
  const dotsContainer = document.querySelector(".control"); 

  carousel.addEventListener("mouseenter", stopAutoplay);
  carousel.addEventListener("mouseleave", startAutoplay);

  dotsContainer.addEventListener("mouseenter", stopAutoplay);
  dotsContainer.addEventListener("mouseleave", startAutoplay);

  
  const radioButtons = document.querySelectorAll(".control");
  radioButtons.forEach((radioButton, index) => {
    radioButton.addEventListener("click", () => {
      
      slideIndex = index; // Update the slide index based on manual selection
      slidesContainer.style.transform = `translateX(-${slideIndex * 100}%)`;
      updateRadioButtons();
stopAutoplay();       
    });
  });

  updateRadioButtons();
  startAutoplay();
});















