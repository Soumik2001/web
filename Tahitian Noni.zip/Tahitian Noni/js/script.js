document.addEventListener("DOMContentLoaded", function () {
  const coll = document.getElementsByClassName("collapsible");
  const mainImage = document.getElementById("mainImage");

  for (let i = 0; i < coll.length; i++) {
    coll[i].addEventListener("click", function () {
      // Close all other sections
      for (let j = 0; j < coll.length; j++) {
        if (coll[j] !== this) {
          coll[j].classList.remove("active");
          let content = coll[j].nextElementSibling;
          if (content) content.style.maxHeight = null;
        }
      }

      // Toggle the clicked section
      this.classList.toggle("active");
      let content = this.nextElementSibling;
      if (content) {
        if (content.style.maxHeight) {
          content.style.maxHeight = null;
        } else {
          content.style.maxHeight = content.scrollHeight + "px";
        }
      }

      // Change the image with fade animation
      const newImageSrc = this.getAttribute("data-image");
      if (newImageSrc && mainImage.src !== newImageSrc) {
        // Trigger fade-out animation
        mainImage.classList.add("fade-out");

        // Wait for fade-out to complete before changing the image
        setTimeout(() => {
          mainImage.src = newImageSrc;
          mainImage.classList.remove("fade-out");
          mainImage.classList.add("fade-in");

          // Remove fade-in class after animation
          setTimeout(() => {
            mainImage.classList.remove("fade-in");
          }, 300); // Match CSS transition duration
        }, 300); // Match CSS transition duration
      }
    });
  }

  // Activate the first collapsible by default
  if (coll.length > 0) {
    const firstCollapsible = coll[0];
    const firstContent = firstCollapsible.nextElementSibling;

    firstCollapsible.classList.add("active");
    if (firstContent) {
      firstContent.style.maxHeight = firstContent.scrollHeight + "px";
    }
    mainImage.src = firstCollapsible.getAttribute("data-image");
  }
});
