const modal = document.getElementById("myModal");
const modalImg = document.getElementById("modalImg");
const captionText = document.getElementById("caption");
const closeModal = document.getElementsByClassName("close")[0];
const images = document.querySelectorAll(".image-popup");

let currentIndex = 0;

images.forEach((img, index) => {
    img.addEventListener("click", function () {
        currentIndex = index; 
        showModal();
    });
});

closeModal.addEventListener("click", function () {
    modal.style.display = "none";
});

function showModal() {
    modal.style.display = "table";
    modalImg.src = images[currentIndex].src;
    captionText.innerHTML = images[currentIndex].alt;

    // Set specific class for boy.gif


    if (images[currentIndex].src.includes('boy.gif')) {
        modalImg.classList.add('boy-gif'); 
    } else {
        modalImg.classList.remove('boy-gif'); 
    }
toggleButtons();
}

function updateModal() {
    modalImg.src = images[currentIndex].src;
    captionText.innerHTML = images[currentIndex].alt;

    // Set specific class for boy.gif
    if (images[currentIndex].src.includes('boy.gif')) {
        modalImg.classList.add('boy-gif'); 
    } else {
        modalImg.classList.remove('boy-gif'); 
    }
toggleButtons();
}

document.addEventListener("keydown", function (event) {
    if (event.key === "Escape") {
        modal.style.display = "none"; 
    }
});

/*window.addEventListener('keydown', event => {
  if (event.key == "ArrowLeft") {
    currentIndex = (currentIndex === 0) ? images.length - 1 : currentIndex - 1;
    updateModal();

  }else if (event.key == "ArrowRight") {
   currentIndex = (currentIndex === images.length - 1) ? 0 : currentIndex + 1;
    updateModal();
  }
}); */

// Next and Previous functionality
document.querySelector(".prev").addEventListener("click", function () {
    currentIndex = (currentIndex === 0) ? images.length - 1 : currentIndex - 1;
    updateModal();
});

document.querySelector(".next").addEventListener("click", function () {
    currentIndex = (currentIndex === images.length - 1) ? 0 : currentIndex + 1;
    updateModal();
});

function toggleButtons(){

//document.querySelector(".prev").style.display="inline-block";
//document.querySelector(".next").style.display="inline-block";

if(currentIndex===0){
document.querySelector(".prev").style.display="none";	
}else{
document.querySelector(".prev").style.display="inline-block";
}

if(currentIndex===images.length - 1){
document.querySelector(".next").style.display="none";
}else{
document.querySelector(".next").style.display="inline-block";
}
}