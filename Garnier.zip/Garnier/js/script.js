function responsiveSlider() {
  const slider = document.querySelector('.swiperSection');
  const sliderList = slider.querySelector('ul');
  const prev = document.getElementById('prev');
  const next = document.getElementById('next');

  if (!slider || !sliderList || !prev || !next) {
    alert('Elements not found. Make sure #prev, #next, and .swiperSection ul exist.');
    return;
  }

  const itemsToShow = 5; 
  const totalItems = sliderList.querySelectorAll('li').length;
  const effectiveWidth = 910; 
  const itemWidth = effectiveWidth / itemsToShow; 
  let currentPosition = 0;

 
  slider.style.width = '960px'; 
  sliderList.style.width = `${itemWidth * totalItems}px`;
  sliderList.querySelectorAll('li').forEach((item) => {
    item.style.width = `${itemWidth}px`;
  });

  function nextSlide() {
    if (currentPosition > -(itemWidth * (totalItems - itemsToShow))) {
      currentPosition -= itemWidth * itemsToShow;
    } else {
      currentPosition = 0; 
    }
    updateSliderPosition();
  }

  function prevSlide() {
    if (currentPosition < 0) {
      currentPosition += itemWidth * itemsToShow;
    } else {
      currentPosition = -(itemWidth * (totalItems - itemsToShow));
    }
    updateSliderPosition();
  }

  function updateSliderPosition() {
    sliderList.style.transform = `translateX(${currentPosition}px)`;
BtnVisibility();
  }


function BtnVisibility(){
prev.style.display = (currentPosition === 0) ? 'none' : 'flex';

    const maxPosition = -(itemWidth * (totalItems - itemsToShow));

    next.style.display = (currentPosition <= maxPosition) ? 'none' : 'flex';

}

BtnVisibility();

  prev.addEventListener('click', prevSlide);
  next.addEventListener('click', nextSlide);
}

window.onload = responsiveSlider;





