document.addEventListener('DOMContentLoaded', function () {
  const bars = document.querySelectorAll('.bar');
  const categories = document.querySelectorAll('.category');
  
  let activeCategoryIndex = 0;
  
  function changeCategory(index) {

    categories[activeCategoryIndex].classList.remove('active');
    bars[activeCategoryIndex].classList.remove('active');
    
    categories[index].classList.add('active');
    bars[index].classList.add('active');
    
    activeCategoryIndex = index;
  }
  
  bars.forEach((bar, index) => {
    bar.addEventListener('click', function () {
      changeCategory(index);
    });
  });

  // Initialize with the first category active
  changeCategory(activeCategoryIndex);
});








document.querySelectorAll('.tnav').forEach(navLink => {
  navLink.addEventListener('click', function (e) {
    e.preventDefault();

    // Remove 'active' class from all navigation links
    document.querySelectorAll('.tnav').forEach(link => link.classList.remove('active'));

    // Add 'active' class to clicked link
    this.classList.add('active');

    // Show the loader while switching sections
    const loader = document.querySelector('.loader');
    loader.classList.add('active');

    // Hide all sections
    document.querySelectorAll('.list').forEach(section => {
      section.classList.remove('visible');
    });

    // Get the target section to show
    const targetSection = document.getElementById(this.getAttribute('data-section'));
    
    // Wait for the loader animation to finish
    setTimeout(() => {
      // Hide the loader and show the target section
      loader.classList.remove('active');
      targetSection.classList.add('visible');
    }, 1000); // Adjust delay as needed for the loader
  });
});







