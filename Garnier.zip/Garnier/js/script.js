function responsiveSlider() {
  const slider = document.querySelector('.swiperSection');
  const sliderList = slider.querySelector('ul');
  const prev = document.getElementById('prev');
  const next = document.getElementById('next');

  if (!slider || !sliderList || !prev || !next) {
    alert('Elements not found. Make sure #prev, #next, and .swiperSection ul exist.');
    return;
  }

  const itemsToShow = 5; // Number of items to show at once
  const totalItems = sliderList.querySelectorAll('li').length; // Total number of images
  const effectiveWidth = 910; // Width available for images
  const itemWidth = effectiveWidth / itemsToShow; // Width of each image
  let currentPosition = 0; // Current position in the slider

  // Set slider dimensions
  slider.style.width = '960px';
  sliderList.style.width = `${itemWidth * totalItems}px`;
  sliderList.querySelectorAll('li').forEach((item) => {
    item.style.width = `${itemWidth}px`;
  });

  function nextSlide() {
    // Calculate maximum position for the last slide
    const maxPosition = -(itemWidth * (totalItems - itemsToShow));

    if (currentPosition > maxPosition) {
      currentPosition -= itemWidth * itemsToShow; // Move to the next set of images
    }

    // If the next position goes beyond maxPosition, show last 5 images
    if (currentPosition < maxPosition) {
      currentPosition = maxPosition; // Set to show the last 5 images
    }
    updateSliderPosition();
  }

  function prevSlide() {
    const maxPosition = -(itemWidth * (totalItems - itemsToShow));

    // Check if we're at the last slide and move back only first 3 images, keeping the last 2
    if (currentPosition === maxPosition) {
      currentPosition += itemWidth * 3; // Move back only 3 items, keeping last 2 images in place
    } else if (currentPosition < 0) {
      currentPosition += itemWidth * itemsToShow; // Move back by full set if not at last slide
    }

    // If the currentPosition goes above 0, reset to the start
    if (currentPosition > 0) {
      currentPosition = 0; 
    }
    updateSliderPosition();
  }

  function updateSliderPosition() {
    sliderList.style.transform = `translateX(${currentPosition}px)`;
    BtnVisibility();
  }

  function BtnVisibility() {
    prev.style.display = (currentPosition === 0) ? 'none' : 'flex';
    const maxPosition = -(itemWidth * (totalItems - itemsToShow));
    next.style.display = (currentPosition <= maxPosition) ? 'none' : 'flex';
  }

  BtnVisibility();

  prev.addEventListener('click', prevSlide);
  next.addEventListener('click', nextSlide);
}

window.onload = responsiveSlider;
