document.addEventListener('DOMContentLoaded', function () {
  const bars = document.querySelectorAll('.bar');
  const categories = document.querySelectorAll('.category');
  
  let activeCategoryIndex = 0;
  
  function changeCategory(index) {

    categories[activeCategoryIndex].classList.remove('active');
    bars[activeCategoryIndex].classList.remove('active');
    
    categories[index].classList.add('active');
    bars[index].classList.add('active');
    
    activeCategoryIndex = index;
  }
  
  bars.forEach((bar, index) => {
    bar.addEventListener('click', function () {
      changeCategory(index);
    });
  });

  // Initialize with the first category active
  changeCategory(activeCategoryIndex);
});



// const navLinks = document.querySelectorAll('.tnav');
// const sections = document.querySelectorAll('.list');
// const loader = document.querySelector('.loader');

// navLinks.forEach(link => {
//   link.addEventListener('click', function (event) {
//     event.preventDefault();

//     // Remove the 'active' class from all nav links
//     navLinks.forEach(link => link.classList.remove('active'));

//     // Add the 'active' class to the clicked link
//     this.classList.add('active');

//     // Hide all sections
//     sections.forEach(section => section.style.display = 'none');

//     // Show loader
//     loader.style.display = 'block';

//     // Hide loader and show the selected section after a delay
//     setTimeout(() => {
//       const sectionId = this.getAttribute('data-section');
//       document.getElementById(sectionId).style.display = 'block';
//       loader.style.display = 'none';
//     }, 1200); // Adjust the timeout for your loading experience
//   });
// });

const navLinks = document.querySelectorAll('.tnav');
const sections = document.querySelectorAll('.list');
const loader = document.querySelector('.loader');

// Set the first section (News) as active and show it by default
document.querySelector('.tnav[data-section="news"]').classList.add('active');
document.querySelector('.tnav[data-section="news"]').style.cursor = 'default'; // Set cursor to default for the default active link
document.getElementById('news').style.display = 'block'; // Show the news section by default

navLinks.forEach(link => {
  link.addEventListener('click', function (event) {
    event.preventDefault();

    // Check if the clicked link is already active
    if (this.classList.contains('active')) {
      return; // Do nothing if it's already active
    }

    // Set cursor to default for all links initially
    navLinks.forEach(link => link.style.cursor = 'pointer'); // Reset cursor for all links
    this.style.cursor = 'default'; // Set cursor to default for the clicked (active) link

    // Remove the 'active' class from all nav links
    navLinks.forEach(link => link.classList.remove('active'));

    // Add the 'active' class to the clicked link
    this.classList.add('active');

    // Hide all sections
    sections.forEach(section => section.style.display = 'none');

    // Show loader
    loader.style.display = 'block';

    // Hide loader and show the selected section after a delay
    setTimeout(() => {
      const sectionId = this.getAttribute('data-section');
      document.getElementById(sectionId).style.display = 'block';
      loader.style.display = 'none';
    }, 1000); // Adjust the timeout for your loading experience
  });
});





