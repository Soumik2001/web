document.addEventListener("DOMContentLoaded", function () {
  const collapsibles = document.querySelectorAll(".collapsible");
  const mainImage = document.getElementById("mainImage");

  // Function to change the image source
  function changeImageSource(newImageUrl) {
    if (newImageUrl) {
      // Preload the new image
      const tempImage = new Image();
      tempImage.src = newImageUrl;

      tempImage.onload = () => {
        mainImage.style.opacity = "0"; // Start fade-out
        setTimeout(() => {
          mainImage.src = newImageUrl; // Change image source
          mainImage.style.opacity = "1"; // Start fade-in
        }, 300); // Match with transition duration
      };
    }
  }

  // Add click event listeners to each collapsible
  collapsibles.forEach((button) => {
    button.addEventListener("click", function () {
      // Remove active class and close other content sections
      collapsibles.forEach((otherButton) => {
        otherButton.classList.remove("active");
        const content = otherButton.nextElementSibling;
        if (content) {
          content.style.maxHeight = null; // Collapse the content
        }
      });

      // Set the clicked button as active
      this.classList.add("active");

      // Expand the content of the active button
      const content = this.nextElementSibling;
      if (content) {
        content.style.maxHeight = content.scrollHeight + "px"; // Expand content
      }

      // Change the image source
      const newImageUrl = this.getAttribute("data-image");
      changeImageSource(newImageUrl);
    });
  });

  // Initialize the first collapsible as active
  const initialButton = collapsibles[0];
  if (initialButton) {
    initialButton.classList.add("active");
    const initialImage = initialButton.getAttribute("data-image");
    changeImageSource(initialImage);

    const initialContent = initialButton.nextElementSibling;
    if (initialContent) {
      initialContent.style.maxHeight = initialContent.scrollHeight + "px";
    }
  }
});
