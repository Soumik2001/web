document.querySelectorAll('.footerUL li').forEach(item=>{
item.addEventListener('click',()=>{
const link = item.querySelector('a');

if(link){
window.location.href=link.href;
window.open = link.href;
}
})
})




document.addEventListener('DOMContentLoaded', function () {
    // Get all the radio buttons for the slider
    const slides = document.querySelectorAll('input[name="slider"]');
    
    // Get all the images, headings, and paragraphs
    const slideImages = document.querySelectorAll('.slider-img'); // Images for the slides
    const slideHeadings = document.querySelectorAll('.heading'); // Headings for the slides
    const paraTexts = document.querySelectorAll('.para'); // Text content for the slides
  
    // Function to update the slider display based on the checked radio button
    function updateSlider() {
      slides.forEach((slide, index) => {
        if (slide.checked) {
          // Hide all slides
          paraTexts.forEach((para) => para.style.display = 'none');
          slideImages.forEach((img) => img.style.display = 'none');
          slideHeadings.forEach((heading) => heading.style.display = 'none');
          
          // Show the current slide
          paraTexts[index].style.display = 'block';
          slideImages[index].style.display = 'block';
          slideHeadings[index].style.display = 'block';
        }
      });
    }
  
    // Initially set the slider based on the checked radio button (in case it's set to slide 2, for example)
    updateSlider();
  
    // Add an event listener to each radio button to update the slider when a new radio button is clicked
    slides.forEach(slide => {
      slide.addEventListener('change', updateSlider);
    });
  });
  
    


  // Get all the radio buttons and slides
const radioButtons = document.querySelectorAll('.control');
const slides = document.querySelectorAll('.para');

// Function to change the slide visibility
function changeSlide() {
  slides.forEach((slide, index) => {
    if (radioButtons[index].checked) {
      // Fade out all other slides first
      slide.style.opacity = 0;
      slide.style.zIndex = -1;
    } else {
      // Reset opacity for all slides except the checked one
      slide.style.opacity = 0;
      slide.style.zIndex = -1;
    }
  });

  // Now wait for the fade out to complete before showing the selected slide
  setTimeout(() => {
    slides.forEach((slide, index) => {
      if (radioButtons[index].checked) {
        // Fade in the checked slide
        slide.style.transition = 'opacity 1s ease-in-out';
        slide.style.opacity = 1;
        slide.style.zIndex = 1;
      }
    });
  }, 100); // Set the delay to match the fade-out time (in ms)
}

// Add event listeners to radio buttons
radioButtons.forEach((button) => {
  button.addEventListener('change', () => {
    changeSlide(); // Change slide when a radio button is selected
  });
});

// Initialize the first slide to be visible (just in case)
changeSlide();





document.addEventListener("DOMContentLoaded", function () {
  const p1 = document.querySelector("#para1");
const p2 = document.querySelector("#para2");
const p3 = document.querySelector("#para3");
const p4 = document.querySelector("#para4");
const p5 = document.querySelector("#para5");


const btn = document.querySelector(".dots");

  function adjustButtonMargin() {
    const paraHeight1 = p1.offsetHeight;
const paraHeight2 = p2.offsetHeight;
const paraHeight3 = p3.offsetHeight;
const paraHeight4 = p4.offsetHeight;
const paraHeight5 = p5.offsetHeight;



    if (paraHeight1 > 190 && paraHeight1 < 240) {
      p1.style.marginBottom="25px";
btn.style.marginTop="15px";
btn.style.paddingBottom="15px";
    } else if(paraHeight1 > 240){
      p1.style.marginBottom="30px";
btn.style.marginTop="15px";
btn.style.paddingBottom="15px";
}
if (paraHeight2 > 190 && paraHeight2 < 240) {
      p2.style.marginBottom="25px";
btn.style.marginTop="15px";
btn.style.paddingBottom="15px";
    } else if(paraHeight2 > 240){
      p2.style.marginBottom="30px";
btn.style.marginTop="15px";
btn.style.paddingBottom="15px";
}

if (paraHeight3 > 190 && paraHeight3 < 240) {
      p3.style.marginBottom="25px";
btn.style.marginTop="15px";
btn.style.paddingBottom="15px";
    } else if(paraHeight3 > 240){
      p3.style.marginBottom="30px";
btn.style.marginTop="15px";
btn.style.paddingBottom="15px";
}


if (paraHeight4 > 190 && paraHeight4 < 240) {
      p4.style.marginBottom="25px";
btn.style.marginTop="15px";
btn.style.paddingBottom="15px";
    } else if(paraHeight4 > 240){
      p4.style.marginBottom="30px";
btn.style.marginTop="15px";
btn.style.paddingBottom="15px";
}

if (paraHeight5 > 190 && paraHeight5 < 240) {
      p5.style.marginBottom="25px";
btn.style.marginTop="15px";
btn.style.paddingBottom="15px";
    } else if(paraHeight5 > 240){
      p5.style.marginBottom="30px";
btn.style.marginTop="15px";
btn.style.paddingBottom="15px";
}

  }

  adjustButtonMargin();

  window.addEventListener("resize", adjustButtonMargin);

  const observer = new MutationObserver(adjustButtonMargin);
  observer.observe(p1, { childList: true, subtree: true });
observer.observe(p2, { childList: true, subtree: true });
observer.observe(p3, { childList: true, subtree: true });
observer.observe(p4, { childList: true, subtree: true });
observer.observe(p5, { childList: true, subtree: true });
});
































































// const radioButtons = document.querySelectorAll('.control');
// const slides = document.querySelectorAll('.para');


// function changeSlide() {
//   slides.forEach((slide, index) => {
//     if (radioButtons[index].checked) {
      
//       if (index === 1) {
//         slide.style.transition = 'none';  // No transition for second slide
//       } else {
//         slide.style.transition = 'opacity 1s ease-in-out';  // Apply transition for other slides
//       }
      
//       // Fade out all other slides first
//       slide.style.opacity = 0;
//       slide.style.zIndex = -1;
//     } else {
//       // Reset opacity for all slides except the checked one
//       slide.style.opacity = 0;
//       slide.style.zIndex = -1;
//     }
//   });

//   // Now wait for the fade-out to complete before showing the selected slide
//   setTimeout(() => {
//     slides.forEach((slide, index) => {
//       if (radioButtons[index].checked) {
//         // Fade in the checked slide
//         slide.style.opacity = 1;
//         slide.style.zIndex = 1;
//       }
//     });
//   }, 100); // Set the delay to match the fade-out time (in ms)
// }

// // Add event listeners to radio buttons
// radioButtons.forEach((button) => {
//   button.addEventListener('change', () => {
//     changeSlide(); // Change slide when a radio button is selected
//   });
// });

// // Initialize the first slide to be visible (just in case)
// changeSlide();
