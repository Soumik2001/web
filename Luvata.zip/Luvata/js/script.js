document.querySelectorAll('.footerUL li').forEach(item=>{
item.addEventListener('click',()=>{
const link = item.querySelector('a');

if(link){
window.location.href=link.href;
window.open = link.href;
}
})
})


document.addEventListener('DOMContentLoaded', function () {
  const radioButtons = document.querySelectorAll('.control');
  const slides = document.querySelectorAll('.para');

  let currentIndex = 0; // To track the current slide index

  // Function to handle the right-to-left transition effect
  function changeSlide() {
      const previousIndex = currentIndex;

      // Find the newly selected radio button index
      radioButtons.forEach((button, index) => {
          if (button.checked) {
              currentIndex = index;
          }
      });

      // Apply transitions and visibility
      slides.forEach((slide, index) => {
          if (index === previousIndex) {
              // Slide out the previous slide to the left
              slide.style.transition = 'transform 0.5s ease-in-out, opacity 0.5s ease-in-out';
              slide.style.transform = 'translateX(-100%)';
              slide.style.opacity = 0;
              slide.style.zIndex = -1;
              slide.style.display = 'none'; // Hide after the transition
          } else if (index === currentIndex) {
              // Set initial position for the new slide (off-screen to the right)
              slide.style.transition = 'none';
              slide.style.transform = 'translateX(100%)';
              slide.style.opacity = 0;
              slide.style.zIndex = 1;
              slide.style.display = 'block'; // Ensure it's visible

              // Slide in the new slide
              setTimeout(() => {
                  slide.style.transition = 'transform 0.5s ease-in-out, opacity 0.5s ease-in-out';
                  slide.style.transform = 'translateX(0)';
                  slide.style.opacity = 1;
              }, 50); // Short delay to ensure smooth transition
          } else {
              // Hide non-active slides
              slide.style.transition = 'none';
              slide.style.transform = 'translateX(100%)';
              slide.style.opacity = 0;
              slide.style.zIndex = -1;
              slide.style.display = 'none'; // Ensure they are hidden
          }
      });
  }

  // Add event listeners to radio buttons
  radioButtons.forEach((button) => {
      button.addEventListener('change', changeSlide);
  });

  // Initialize the slider with the default checked slide
  changeSlide();
});






document.addEventListener("DOMContentLoaded", function () {
  const p1 = document.querySelector("#para1");
const p2 = document.querySelector("#para2");
const p3 = document.querySelector("#para3");
const p4 = document.querySelector("#para4");
const p5 = document.querySelector("#para5");


const btn = document.querySelector(".dots");

  function adjustButtonMargin() {
    const paraHeight1 = p1.offsetHeight;
const paraHeight2 = p2.offsetHeight;
const paraHeight3 = p3.offsetHeight;
const paraHeight4 = p4.offsetHeight;
const paraHeight5 = p5.offsetHeight;



    if (paraHeight1 > 190 && paraHeight1 < 240) {
      p1.style.marginBottom="25px";
btn.style.marginTop="15px";
btn.style.paddingBottom="15px";
    } else if(paraHeight1 > 240){
      p1.style.marginBottom="30px";
btn.style.marginTop="15px";
btn.style.paddingBottom="15px";
}
if (paraHeight2 > 190 && paraHeight2 < 240) {
      p2.style.marginBottom="25px";
btn.style.marginTop="15px";
btn.style.paddingBottom="15px";
    } else if(paraHeight2 > 240){
      p2.style.marginBottom="30px";
btn.style.marginTop="15px";
btn.style.paddingBottom="15px";
}

if (paraHeight3 > 190 && paraHeight3 < 240) {
      p3.style.marginBottom="25px";
btn.style.marginTop="15px";
btn.style.paddingBottom="15px";
    } else if(paraHeight3 > 240){
      p3.style.marginBottom="30px";
btn.style.marginTop="15px";
btn.style.paddingBottom="15px";
}


if (paraHeight4 > 190 && paraHeight4 < 240) {
      p4.style.marginBottom="25px";
btn.style.marginTop="15px";
btn.style.paddingBottom="15px";
    } else if(paraHeight4 > 240){
      p4.style.marginBottom="30px";
btn.style.marginTop="15px";
btn.style.paddingBottom="15px";
}

if (paraHeight5 > 190 && paraHeight5 < 240) {
      p5.style.marginBottom="25px";
btn.style.marginTop="15px";
btn.style.paddingBottom="15px";
    } else if(paraHeight5 > 240){
      p5.style.marginBottom="30px";
btn.style.marginTop="15px";
btn.style.paddingBottom="15px";
}

  }

  adjustButtonMargin();

  window.addEventListener("resize", adjustButtonMargin);

  const observer = new MutationObserver(adjustButtonMargin);
  observer.observe(p1, { childList: true, subtree: true });
observer.observe(p2, { childList: true, subtree: true });
observer.observe(p3, { childList: true, subtree: true });
observer.observe(p4, { childList: true, subtree: true });
observer.observe(p5, { childList: true, subtree: true });
});
























































